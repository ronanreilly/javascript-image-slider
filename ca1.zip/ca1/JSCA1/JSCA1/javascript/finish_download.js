window.navigate("http://www.google.com");
