function validateRegEx(regex, input, helpText, helpMessage) {
	// See if the input data validates OK
	if (!regex.test(input)) {
		// The data is invalid, so set the help message and return false
		if (helpText != null) helpText.innerHTML = helpMessage;
		return false;
	} else {
		// The data is OK, so clear the help message and return true
		if (helpText != null) helpText.innerHTML = "";
		return true;
	}
}

function notEmpty(inputField, helpText) {
	// See if the input value contains any text
	return validateRegEx(/.+/, inputField.value, helpText, "This field is required!");
}

function valNoChars(minLength, maxLength, inputField, helpText) {
	// See if the input value contains at least minLength but no more than maxLength characters
	return validateRegEx(new RegExp("^.{" + minLength + "," + maxLength + "}$"), inputField.value, helpText, "Must be be between " + minLength + " to " + maxLength + " characters.");
}

function valEmailFormat(inputField, helpText) {
	// First see if the input value contains data
	if (!notEmpty(inputField, helpText)) return false;
	// Then see if the input value is an email address
	return validateRegEx(/^[\w\.-_\+]+@[\w-]+(\.\w{2,3})+$/, inputField.value, helpText, "Please enter a valid email address!");
}

function valPhoneNum(inputField, helpText) {
	// First see if the input value contains data
	if (!notEmpty(inputField, helpText)) return false;
	// Then see if the input value is a phone number
	return validateRegEx(/^\d{3}-\d{2}-\d{5}$/, inputField.value, helpText, "Not a valid phone Number! (for example, 041-98-32796).");
}

function beginThisValidation(form) {
	if (valNoChars(1, 50, form["name"], form["name_error"]) && valEmailFormat(form["email"], form["email_error"]) && valPhoneNum(form["phone"], form["phone_error"])){
	
	if (document.getElementById("Yes").checked == false && document.getElementById("No").checked == false) {
		document.getElementById('news_error').innerHTML = "Please select Yes or Now";
		document.getElementById('news_error').style.color = "red";
	}
		// Submit the order to the server
		form.submit();
	} else {
		alert("Please fill in all the required fields with the correct data.");
	}
}